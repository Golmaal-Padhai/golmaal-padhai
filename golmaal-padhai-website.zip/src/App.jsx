import { useState } from 'react'
import { motion } from 'framer-motion'

export default function App() {
  const [ordered, setOrdered] = useState(false)

  return (
    <div>
      <nav style={{display:'flex',justifyContent:'space-between',padding:'20px',borderBottom:'1px solid #333'}}>
        <h2>Golmaal Padhai</h2>
        <div>
          <a href="#home" style={{marginRight:15}}>Home</a>
          <a href="#services" style={{marginRight:15}}>Services</a>
          <a href="#order" style={{marginRight:15}}>Order</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section id="home" style={{padding:'80px',textAlign:'center'}}>
        <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}}>
          Smart Study. Real Results.
        </motion.h1>
        <p>Modern learning platform by Golmaal Padhai</p>
      </section>

      <section id="services" style={{padding:'60px',background:'#111'}}>
        <h2>Our Services</h2>
        <ul>
          <li>Class 9–12 Notes (PDF)</li>
          <li>Doubt Solving</li>
          <li>Exam Preparation</li>
        </ul>
      </section>

      <section id="order" style={{padding:'60px'}}>
        <h2>Place Order</h2>
        {!ordered ? (
          <button onClick={()=>setOrdered(true)}>Place Order</button>
        ) : (
          <p style={{color:'lightgreen'}}>Order placed successfully!</p>
        )}
      </section>

      <section id="contact" style={{padding:'60px',background:'#111'}}>
        <h2>Contact / WhatsApp</h2>
        <p>
          <a href="https://wa.me/917814769817">WhatsApp: 7814769817</a>
        </p>
      </section>

      <footer style={{padding:'20px',textAlign:'center',borderTop:'1px solid #333'}}>
        © 2026 Golmaal Padhai
      </footer>
    </div>
  )
}